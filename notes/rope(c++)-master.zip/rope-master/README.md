A modern C++ rope implementation (using C++ 11 memory management features).

Balancing is executed at the discretion of the client, according to the algorithm described originally by Boehm, Atkinson, and Plass: http://citeseer.ist.psu.edu/viewdoc/download?doi=10.1.1.14.9450&rep=rep1&type=pdf.

Build with cmake.
