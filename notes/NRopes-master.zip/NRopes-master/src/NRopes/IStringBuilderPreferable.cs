﻿namespace NRopes {
    using System.Text;

    public interface IStringBuilderPreferable {
        void ToString(StringBuilder sb);
    }
}