NRopes
======

A ropes data structure implementation for .NET